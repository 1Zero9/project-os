# Microsoft Copilot Integration (WIP)

> **Status: Work in progress.** This folder documents a possible future Microsoft 365 Copilot / Copilot Studio implementation. It is not an active deployment and must not be treated as production-ready.

## Is this possible?

Yes. Microsoft 365 Copilot and Copilot Studio support custom agents that can use instructions, knowledge sources, skills, workflows, connectors, actions, MCP tools, and agent-to-agent communication.

The existing GitHub Copilot and Claude Code definitions cannot simply be copied into Microsoft Copilot. The behavior and rules can be reused, but they must be translated into Microsoft's agent model and deployed through Microsoft's supported tools and governance process.

## What we could reuse

- Agent purpose, scope, and trigger descriptions
- Plain-language prompts and examples
- Safety and approval rules
- Update and versioning principles
- Handoff and delegation decisions
- Shared validation and security expectations
- Documentation structure and test scenarios

## What would need translating

| Current repository concept | Possible Microsoft Copilot equivalent |
|---|---|
| `.agent.md` | Copilot Studio agent or Microsoft 365 declarative agent |
| `SKILL.md` | Skill, topic, action, agent flow, or reusable instruction |
| Handoff button | Agent-to-agent routing, topic routing, or workflow delegation |
| Validation hook | Copilot Studio flow, Power Automate flow, or governance control |
| Repository files | SharePoint, OneDrive, Dataverse, connector, MCP tool, or API |
| Git versioning | Copilot Studio solution, environment, or managed deployment process |

## Possible future agents

The existing agents could potentially become Microsoft Copilot agents such as:

- Project Plan Creator for planning and Azure DevOps work items
- Project Buddy for approved automation and scripting workflows
- Endpoint Package Review for deployment package review
- HTHB Generator for SharePoint documentation

Each would need a separate design for knowledge, actions, permissions, data access, testing, publishing, and ownership.

## Access and prerequisites

Implementation should wait until the team has confirmed:

- Microsoft 365 Copilot or Copilot Studio licensing
- Permission to create and publish agents
- Required Power Platform environment and solution access
- SharePoint, Dataverse, Azure DevOps, GitLab, or other connector permissions
- Security, privacy, data-loss-prevention, and compliance approval
- Ownership and support arrangements after publishing
- A test environment that is separate from production

Do not connect real business data or publish an agent from this work-in-progress folder until those approvals are complete.

## Proposed implementation approach

1. Choose one small pilot workflow.
2. Write the platform-neutral behavior and acceptance criteria.
3. Map its knowledge sources, actions, permissions, and handoffs.
4. Build it in a non-production Copilot Studio environment.
5. Test normal, missing-information, unsafe, and permission-denied scenarios.
6. Review security, privacy, licensing, and support requirements.
7. Package and publish only after explicit approval.

## Future Ideas and Plans

Use the [wiki Future Ideas and Plans page](https://gitlab.version1.com/bats/support-services/ai-agents_skills/-/wikis/Home/How-Agents-Work/Future-Ideas-and-Plans) as the shared backlog for Microsoft Copilot and related platform ideas.

Keep entries small and mark them with a clear status such as **Idea**, **Planned**, **Blocked**, **Pilot**, **Complete**, or **Dropped**. Record dependencies, ownership, and the next question rather than treating an idea as approved implementation work.

## Relationship to `agent-creator`

The shared `agent-creator` skill can eventually be extended to produce a Microsoft Copilot design alongside the GitHub Copilot and Claude Code definitions. It should generate a design or build checklist first, not silently create or publish a Microsoft agent.

Potential future prompt:

```text
Use agent-creator to design this workflow for GitHub Copilot, Claude Code, and Microsoft 365 Copilot. Do not publish anything. Include the Microsoft knowledge sources, actions, permissions, handoffs, test cases, and access prerequisites.
```

## Not implemented yet

This folder intentionally contains planning information only. It does not contain:

- A Copilot Studio agent package
- Production connectors
- API credentials or secrets
- Published instructions
- Deployment automation
- Tenant-specific identifiers

Update this document as access, licensing, architecture, and governance decisions become clearer.
