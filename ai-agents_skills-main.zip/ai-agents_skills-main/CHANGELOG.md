# Changelog

All notable changes to the **AI Agents & Skills** central repository are documented here.

> ⚠️ **Do not copy this file to your project repo.** It belongs to this central repository only.
> See the [README](README.md) for the full list of files that must not be copied to project repos.

This changelog covers the repository itself (agents added/updated, structural changes, documentation).
For changes to an individual agent's behaviour, see the Version History table at the bottom of that agent's file.

---

## [Unreleased] — 2026-09-11

### Changed
- **Endpoint Package Review** — added critical safety rule: NEVER install the app on the device during package reviews; only validate scripts through review, metadata analysis, and log inspection.
- **README.md** — clarified that the repository is made of structured Markdown files for agents, skills, hooks, and wiki guidance used by Copilot and Claude Code.
- **Endpoint Package Review** — added Tanium as a default troubleshooting evidence source, prioritising read-only Interact, Asset, Deploy history, Comply, and Trends checks before endpoint actions.
- **Endpoint Package Review** — strengthened customer-file handling so unclear payloads are flagged and the user is prompted before committing, packaging, uploading, or documenting real values.
- **Endpoint Package Review** — added a customer-files and payload safeguard to prevent customer configuration, certificates, licenses, tenant-specific files, and sensitive package inputs from being committed to the central repository.
- **README.md** — moved the agents workflow image directly above the “How the agents work together” explanation.
- **Help Me and Agent Creator** — added the Honey Badger helper persona and an explicit agent-versus-skill-versus-hook-versus-instructions decision framework based on repository structure.
- **README.md** — removed the obsolete Deployed To section and deployment table; deployment guidance remains in the wiki.
- **Endpoint Package Review** — strengthened Avecto guidance so policy and Workstyle suggestions are clearly advisory and require independent investigation, owner approval, peer review, pilot testing, and explicit authorization before implementation.
- **Endpoint Package Review** — documented Low Flex as the default Avecto policy and added Windows Secure Builds/Tanium and macOS Jamf extension-attribute checks for determining device policy.
- **Endpoint Package Review wiki** — consolidated the duplicated page, added a dedicated Avecto log troubleshooting guide, and recorded optional Tanium Atlas integration as a future idea in the README and wiki planning page.
- **Endpoint Package Review** — added the Avecto/Defendpoint Event Viewer evidence checklist to both Copilot and Claude definitions and the wiki, including command line, Workstyle, file/product metadata, application group and Workstyle descriptions.
- **Quick Start and Endpoint Package Review** — added one-paste Windows and macOS setup prompts for destination folders and toolsets, and documented Jamf, Tanium, GlobalProtect, Avecto, and cross-platform privilege-popup troubleshooting defaults.
- **Help Me: AI Agents & Skills** — added interactive wiki question mode so users can ask plain-language questions, retrieve relevant wiki guidance, and receive source-linked answers.
- **README.md and wiki** — added the AI Agents & Skills logo to the README and documented the difference between agents and shared skills with demo guidance.
- **Help Me: AI Agents & Skills** — added a beginner-friendly Copilot agent, Claude Code command, shared navigation skill, wiki documentation, reviewable handoffs, and example prompts for choosing and using the right agent.
- **Help Me: AI Agents & Skills** — added routing for supporting skills, including PowerShell, deployment package, secret, Azure DevOps, update-check, and agent-creator checklists.
- **Help Me: AI Agents & Skills** — refined rough user requests into complete prompts, added explicit assumption handling, and exposed the helper page in the wiki sidebar.
- **README.md** — removed the standalone Repository Structure reference table; the repository layout remains available through the linked agent and skill documentation.
- **README.md** — updated the Claude Code and GitHub Copilot quick-start links to the current combined wiki guide.
- **README.md** — updated Endpoint Package Review, HTHB Generator, and Troubleshooting links to their new Home subpages in the wiki.
- **Agents and skills** — added a shared startup update check for GitHub Copilot and Claude Code. It asks before updating, supports non-Git folders, and checks `.gitignore` only when a Git repository is present.
- **Agent Creator skill** — added an approval-first workflow for designing paired Copilot and Claude agents, applying repository rules, and suggesting handoffs from the existing agent workflow.
- **Endpoint Package Review** — added a blocking Secure Builds Teams-post evidence prompt and a package README Security Review template requiring the direct discussion link, VMRay findings, approvals, and squad sign-off.
- **Future planning** — added Microsoft Copilot work-in-progress notes and a separate README section for future plans and platform ideas.
- **Endpoint Package Review** — added an optional, confirmation-gated publish workflow for the Endpoint Squad Custom Applications repository, including existing-clone path prompts, safe cloning, folder inspection, and final commit/push approval.
- **Agent maintenance** — added a platform-aware updater for Claude Code, GitHub Copilot, or both, and removed Quarterly Review from the active demo toolsets.

## [1.38.0] — 2026-09-03

### Changed
- **All agents** (Claude Code and GitHub Copilot) — limited the central markdown commit prompt to changes made to the current agent definition file; package READMEs, scripts, wiki pages, and other markdown files no longer trigger it.

## [1.37.0] — 2026-09-03

### Changed
- **Endpoint Package Review** (Claude Code and GitHub Copilot) — added a standalone Windows uninstaller standard for custom packages initiated from Windows Settings or Add/Remove Programs outside Company Portal.

## [1.36.0] — 2026-09-03

### Changed
- **Endpoint Package Review** (Claude Code and GitHub Copilot) — required public support logs under `C:\Logs` for Windows package troubleshooting while preserving platform-native supplemental logs.

## [1.35.0] — 2026-09-03

### Changed
- **Endpoint Package Review** (Claude Code and GitHub Copilot) — documented the available Tanium modules and added guidance for selecting the narrowest suitable workflow.

## [1.34.0] — 2026-09-03

### Changed
- **Endpoint Package Review** (Claude Code, GitHub Copilot, and wiki) — added the required `V1-SS-PIMGroup-IntuneAppManagement` PIM activation notice before uploading Win32 packages to Intune.

## [1.33.0] — 2026-09-01

### Changed
- **Visual guides and standalone agent clarification** — added flowcharts to explain how each agent works, and clarified which agents work standalone vs repo-integrated:
  - **README.md**: Added "Standalone vs Repo-Integrated" section explaining that non-technical users can use Plan Creator and HTHB Generator without a codebase or VS Code
  - **HTHB Generator** (Claude Code & GitHub Copilot): Added "How it works" flowchart showing three input paths (Repo Mode, Document Mode, Quick KB Mode) all producing SharePoint-ready output
  - **Project Plan Creator** (Claude Code & GitHub Copilot): Added "How it works" flowchart showing decision flow (existing plan vs new plan) and the chat-first approval workflow
  - **Project Buddy** (Claude Code & GitHub Copilot): Added visual "Context Detection Flow" flowchart showing silent check for `project.md`, fallback question if not found, and smart handoff logic
  - Flowcharts added to both Copilot and Claude Code versions for consistency

---

## [1.32.0] — 2026-09-01

### Changed
- **Documentation & Onboarding Rewrite** — improved beginner experience across all agents:
  - **README.md**: Added ASCII flowchart showing all four agents in natural workflow sequence; explicit first-timer guidance ("No project yet? Start: `/project-plan-creator`"); updated agent table with "Creates" and "Reads" columns clarifying which agents use `project.md`
  - **Project Plan Creator** (Claude Code & GitHub Copilot): Replaced "What is project.md?" section with detailed tutorial-style "Understanding project.md — Your Project's Brain"; added "Five Sections" breakdown (What, Who, When, Risks, Weekly Log) with concrete examples and explanations of why each section matters; clarified how `project.md` creates team alignment across the workflow
  - **Project Buddy** (Claude Code): Added "Context Detection — Project.md Integration" section describing silent check for existing `project.md`, context-aware intake planning, and smart handoff logic; updated Phase 0 intake instructions to read and use `project.md` if present
  - Tone: friendly-professional throughout, assumes zero knowledge, guides beginners naturally to first agents

---

## [1.31.0] — 2026-09-01

### Changed
- **Project Plan Creator** (Claude Code & GitHub Copilot) — major rewrite for human-first planning:
  - Chat-first workflow: generate plan in chat, user approves, then save files only (not auto-create on intake)
  - Simplified intake from 6 questions to 4 key questions (single message, all at once)
  - Removed Epic/Feature/User Story jargon; replaced with phase-based natural language
  - Risk tables now conditional on project size (small: none, medium: 4-5 prose risks, large: full table)
  - Task structure simplified: 2-4 tasks per phase (not 8-12 micro-tasks)
  - Built-in Weekly Log section for progress tracking as work happens
  - Project size guidance rewritten for clarity (Small/Medium/Large with practical examples)
  - Flexible for both standalone planning and repo-integrated use (full setup or plan-only)

---

## [1.30.0] — 2026-09-01

### Changed
- **Project Buddy** (Claude Code & GitHub Copilot) — broadened scope beyond PowerShell to enterprise automation projects:
  - Renamed from endpoint-focused to platform-agnostic "Enterprise Automation and Planning Agent"
  - Expanded supported languages: PowerShell, Python, Bash, hybrid solutions
  - Extended system coverage: Tanium, Intune, ITAM, SQL, SharePoint, Microsoft Graph, Azure, on-prem, third-party integrations
  - Updated "When to use" to reflect DevOps, infrastructure, automation, reporting, deployment pipelines
  - Added 3 new example prompts showing broader project scope (Python tools, SQL dashboards, AD/ITAM reconciliation)
  - Updated handoff: `/endpoint-package-review` instead of `/pmpc-powershell`; clarified multi-platform deployment (Jamf, Tanium, SCCM)

---

## [1.29.0] — 2026-09-01

### Changed
- **HTHB Generator** (Claude Code & GitHub Copilot) — improved KB quality and organizational alignment:
  - Fixed icon consistency: replaced emoji with Unicode symbols (⚙ ⚒ ✘ ► ◆ ⟳)
  - Elevated **Audience-Driven Tone & Content Rules** to dedicated prominent section with internal vs. public examples
  - Replaced ServiceNow/Confluence references with IRIS (ticketing system) and SharePoint (KB platform)
  - Added **SharePoint & IRIS Integration** section: publishing guidance, ticket linking, and KB creation triggers
  - Clarified that SharePoint Modern is the primary KB distribution platform

---

## [1.28.0] — 2026-09-01

### Changed
- **Endpoint Package Review** (Claude Code & GitHub Copilot) — macOS packaging guidance added:
  - New **macOS Packaging Guidance** section with Jamf and Tanium configuration details
  - Pre-packaging assessment questions for platform and deployment method
  - Platform-specific README sections for Jamf and Tanium environments
  - Bash/Zsh logging patterns and script naming conventions for macOS
  - Guidance for scripts targeting both Jamf and Tanium simultaneously

---

## [1.27.0] — 2026-08-31

### Changed
- **HTHB Generator** (Claude Code & GitHub Copilot) — v1.13 released with icon refinement:
  - Replaced Lucid icon references with professional Unicode symbols (⚙ ⚒ ✘ ► ◆ ⟳)
  - Unicode symbols render cleanly across all platforms without publisher setup required
  - Symbols are simpler, more corporate-neutral, and immediately visible in preview/markdown views

---

## [1.26.0] — 2026-08-31

### Changed
- **HTHB Generator** (Claude Code & GitHub Copilot) — v1.12 released with user feedback improvements:
  - Replaced AI-generated emoji with Lucid icon references (`<!-- Lucid: [icon-name] -->` format) for professional KB output
  - Added KB keyword suggestion feature (5-8 keywords per article, chat-only, never added to markdown)
  - Added audience-driven tone rule for public/external audiences (simple language, no jargon, short sentences max 8-12 words)
  - Added SharePoint sidebar navigation guidance for nested list structures (2-3 levels supported with style limitations noted)

---

## [1.25.0] — 2026-08-27

### Fixed
- **README** both PowerShell setup blocks now handle a corrupt/incomplete temp clone gracefully — if `git pull` fails, the broken folder is deleted and a clean `git clone` is performed automatically.

---

## [1.24.0] — 2026-08-27

### Changed
- **Project Buddy** markdown commit prompt rule tightened in both Copilot and Claude Code formats.
- Prompt now only fires when files belonging to this AI Agents_Skills repo are modified — not when working on scripts or docs in a different project repo.

---

## [1.23.0] — 2026-08-26

### Changed
- **HTHB Generator** updated to v1.11 in both Copilot and Claude Code formats.
- Mode Detection now always asks an explicit upfront question — no more auto-detecting from context.
- Added **Document Mode** for HTML, ASPX, Word, PDF, and SharePoint export sources.
- Document Mode includes a mandatory post-analysis cleanup rule: no temp or extracted files left on disk.
- AI diagram prompt question is now a mandatory part of the upfront questions, not a conditional afterthought.

---

## [1.22.0] — 2026-08-25

### Changed
- **HTHB Generator** updated to v1.10 in both Copilot and Claude Code formats.
- Every generated KB article now opens with a generation metadata line showing the agent version and date it was produced.

---

## [1.21.0] — 2026-08-25

### Changed
- **HTHB Generator** updated to v1.9 in both Copilot (`.github/agents/`) and Claude Code (`.claude/commands/`) formats.
- Added **Quick KB Mode** — agent now works without a repo. Users can describe a support issue, fix, or process in chat and receive a complete, structured KB article with no folder or file reads required.
- Added **Mode Detection** section to both files: agent auto-detects Repo Mode vs Quick KB Mode from context.
- Read Strategy updated with a Quick KB gate — skips all file reads when no repo is provided.
- File-write constraint updated: Quick KB output goes to chat first; file is only written if the user explicitly requests it.
- "When to use" and example prompts expanded to cover support KB scenarios.

### Validation
- Troubleshooting-last rule and mandatory Appendix section preserved in both modes.
- Quick KB Mode gracefully handles inapplicable sections (e.g. Recent Changes) with a single N/A statement rather than leaving them empty.

---

## [1.20.0] — 2026-08-19

### Changed
- **HTHB Generator** updated to v1.8 in both Copilot and Claude Code formats.
- AI diagram prompts are now optional and chat-only: the agent asks whether visuals are wanted, shows safe source-grounded prompts in chat, and never adds them to the KB Markdown file.
- Users can request prompts for a specific HTHB section without changing the strict article structure.

### Validation
- Both HTHB formats retain the required Troubleshooting-last rule.
- Chat prompt guidance includes sensitive-data, invented-claim, accessibility, logo, and copyrighted-UI safeguards.

---

## [1.19.0] — 2026-08-18

### Changed
- Removed the four Claude reviewer subagents from `.claude/agents/` so VS Code no longer exposes internal reviewers in the main agent picker.
- Consolidated Claude review workflows into the shared skills under `.claude/skills/`.
- Simplified the cross-platform deployment layout to five user-facing agents plus shared skills:
  - Copilot: `.github/agents/`
  - Claude: `.claude/commands/`
  - Both: `.github/skills/` and `.claude/skills/`
- Updated README setup, update, copy guidance, and prompt examples to remove `.claude/agents/`.

### User Experience
- Copilot and Claude now present the same five primary workflows without exposing implementation-only reviewer choices.
- Specialist checks remain available through `powershell-validation`, `intune-package-review`, `git-weekly-summary`, `secret-scanning`, and `ado-project-planning`.

### Documentation Cleanup
- Removed the final current README reference to Claude specialist subagents; historical changelog entries remain unchanged for release accuracy.

---

## [1.18.0] — 2026-08-18

### Added
- **Shared Agent Skills** mirrored under `.github/skills/` and `.claude/skills/`:
  - `powershell-validation` — PowerShell syntax, ASCII, PSScriptAnalyzer, exit-code, and unattended-execution checks
  - `intune-package-review` — install, detection, uninstall, versioning, logging, and SYSTEM-context review
  - `git-weekly-summary` — verified date-bounded summaries across multiple repositories
  - `secret-scanning` — credential, private endpoint, identifier, and personal-data checks before publication
  - `ado-project-planning` — Azure DevOps planning hierarchy, risks, dependencies, milestones, and progress updates
- **Claude specialist subagents** under `.claude/agents/`:
  - `powershell-reviewer`
  - `security-reviewer`
  - `git-history-analyst`
  - `documentation-reviewer`
- **Copilot reviewer agents** for PowerShell and security review, configured as non-user-invocable delegation targets
- **Copilot delegation** added to Project Buddy and PMPC PowerShell through the `agents` frontmatter property
- **Agent hooks** added under `.github/hooks/` and `.claude/settings.json` for post-tool validation and session-stop whitespace checks

### Changed
- **README** expanded with:
  - An explanation of on-demand skill loading and portability
  - Prompt examples for all five shared skills
  - Claude subagent usage examples
  - Copilot delegation examples
  - Hook behavior, limitations, and security guidance
  - Updated copy, update, and `.gitignore` instructions for all customization folders

### Validation
- Hook JSON parses successfully.
- Hook PowerShell parses successfully and runs successfully with the current repository state.
- Shared skill folder names match their `SKILL.md` names and descriptions.
- `git diff --check` passes.

---

## [1.17.0] — 2026-08-13

### Changed
- **README** (Setup Instructions): Added auto-update callout noting that any agent in any project repo can respond to "update agents" / "pull the latest agents" by running the standard PowerShell clone/pull + copy commands pointing at the central GitLab repository.

---

## [1.16.0] — 2026-08-06

### Changed
- **project-buddy** (v1.7, GitHub + Claude): Elevated ASCII-only to a **HARD RULE** for ALL Tanium and Intune scripts — not just Intune package scripts. Added to Constraints section, Hard Rules table, and Quality Self-Check. Applies to install, detection, remediation, sensors, packages, and helper scripts.
- **pmpc-powershell** (GitHub + Claude): Strengthened existing ASCII DO-NOT rule to **HARD RULE** language, explicitly naming Tanium alongside Intune, covering every script type.

---

## [1.15.0] — 2026-07-30

### Added
- **Handoffs** wired up across all GitHub Copilot agents (`.github/agents/`) — VS Code handoff buttons now appear after each chat response to guide users through the natural workflow chain:
  - **Project Plan Creator → Project Buddy**: After the plan is generated, start scripting the deliverables
  - **Project Buddy → HTHB Generator**: After scripts are complete, generate the KB article
  - **Project Buddy → PMPC PowerShell Package Agent**: After scripts are complete, package for PatchMyPC / Intune Win32
  - **PMPC PowerShell Package Agent → HTHB Generator**: After a package is complete, document it
  - **Quarterly Review Generator → Project Plan Creator**: After reviewing the quarter, plan the next one
  - HTHB Generator has no outbound handoff — documentation is the end of the workflow
- All handoffs use `send: false` so users see the pre-filled prompt and can review/edit before submitting
- Version bumps: `project-buddy` 1.5→1.6, `project-plan-creator` 1.6→1.7, `quarterly-review` 1.1→1.2, `pmpc-powershell` (handoff block added)
- **README** updated with new `## Handoff Workflows` section documenting the full chain

---

## [1.14.0] — 2026-07-29

### Changed
- **`project-buddy.agent.md`** bumped to v1.5 — added 2026 UI trend standards: Sustainable Design guidelines (CSS-first animations, `content-visibility: auto`, `will-change` rules, SVG icons, CLS=0 image dimensions), expanded neurodiversity accessibility rules (no auto-play, colour+icon pairing, ARIA live regions, DOM reading order), and user preference persistence pattern (`localStorage` namespacing for active tab/filter/sort)
- **`.claude/commands/project-buddy.md`** synced to match v1.5 agent body
- **`.claude/commands/quarterly-review.md`** synced to match `quarterly-review.agent.md` body (was missing frontmatter strip from previous copy)

---

## [1.13.0] — 2026-07-29

### Changed
- **`project-buddy.agent.md`** bumped to v1.4 — added full **Premium UI/UX Design Standard** section with complete CSS pattern library (animated mesh background, glassmorphism panels, CSS variable system, gradient hero, premium toggle buttons, chart cards, stat cards, entrance animations, typography scale, and accessibility rules); added two new Quality Self-Check bullets covering Premium UI/UX and dark/light mode standards
- **`.claude/commands/project-buddy.md`** synced to match v1.4 agent file body

---

## [1.12.0] — 2026-07-28

### Added
- **Update agents rule** added to all 10 agent files (5 `.github/agents/` + 5 `.claude/commands/`)
- Any agent in any project repo can now respond to "update agents" or "pull the latest agents" by running the standard PowerShell clone/pull + copy commands pointing at the central GitLab repository
- Rule is consistently placed after the Lessons learned rule in every file

### Changed
- **Quarterly Review Generator** — added `## 🤖 About this Agent` section, `### When to use`, `### Example prompts`, and "copying agents" rules to match the structure of all other agents
- `quarterly-review.agent.md` promoted to v1.1 with full YAML frontmatter restored (name, description, tools, model, argument-hint, version, updated)

---

## [1.11.0] — 2026-07-28

### Added
- **Quarterly Review Generator** agent — new agent (`quarterly-review.agent.md` / `quarterly-review.md`) that analyses the last 3 months of git history and produces a human-sounding self-assessment draft for quarterly performance conversations
- Collects real stats: commit count, lines of code added/removed, projects/areas touched
- Output written to `quarterly-reviews/QR-<YYYY>-Q<N>-draft.md`; agent auto-adds `quarterly-reviews/` to `.gitignore` to prevent personal drafts being committed
- Strict no-AI-filler writing rules enforced: no "leveraged", "spearheaded", "synergized" etc.
- Supports multi-repo aggregation — provide multiple repo paths and stats are combined into one draft
- Added `/quarterly-review` to CLAUDE.md command table

---

## [1.10.0] — 2026-07-22

### Added
- **Heavy commenting — MANDATORY** rule added to all code-producing agents (**Project Buddy** and **PMPC PowerShell Package Agent**) in both GitHub Copilot agent files and Claude Code command files
- Rule requires every function, logical section (loops, conditionals, try/catch), and variable declaration to be commented; non-obvious logic must be flagged with a `# WHY:` note; exit points must state the triggering condition and exit code; comments must explain *why*, not just *what*
- **Regions — MANDATORY** sub-rule added: every script must be divided into named `#region` / `#endregion` blocks with descriptive names (e.g. `#region Config`, `#region Functions`, `#region Main Logic`, `#region Cleanup`); every `#region` must pair with a matching `#endregion`
- Applies wherever it is relevant: Project Plan Creator and HTHB Generator are excluded as they produce no code

### Changed
- `project-buddy.agent.md` bumped from v1.2 → v1.3
- `pmpc-powershell.agent.md` updated to include heavy commenting and regions rule in Phase 3 — Implement

---

## [1.9.0] — 2026-07-21

### Added
- Root README now documents the **markdown change rule**: ask before committing or pushing `.md` changes to the central repository
- Root README now documents the **main repo commit rule**: if the user explicitly asks for a commit to the central repo, add a short summary to the root `CHANGELOG.md` instead of copying a project changelog, then commit and push after syncing with remote
- Root README now documents the **lessons learned rule**: capture reusable project patterns, pitfalls, safeguards, and decisions in `Lessons Learned` or `Learned Patterns` sections

### Changed
- All GitHub Copilot agent files and Claude Code command files now instruct agents to always prompt before committing markdown changes
- All GitHub Copilot agent files and Claude Code command files now instruct agents to add a short summary to the root `CHANGELOG.md`, not copy project changelog entries, then commit and push when explicitly asked to update the main AI Agents_Skills repo
- All GitHub Copilot agent files and Claude Code command files now instruct agents to capture reusable lessons learned for future project work

---

## [1.8.0] — 2026-07-21

### Added
- **PMPC PowerShell Package Agent** (`pmpc-powershell.agent.md` + `.claude/commands/pmpc-powershell.md`) added to the central repo — PatchMyPC Cloud / Intune / SCCM deployment scripting agent

### Deployed
- **Project Buddy** (`project-buddy.agent.md` + `.claude/commands/project-buddy.md`) deployed to `pmpc-custom-applications` repo — `.github/agents/` and `.claude/commands/` folders created in that repo

---

## [1.7.0] — 2026-07-21

### Added
- **Tooling & Environment Notes** section added to `project-plan-creator` — documents that macOS MDM is Jamf Pro (not Intune), Windows MDM is Intune, endpoint tooling is Tanium, and identity is Entra ID
- **Project size guidance** (Q6) added to `project-plan-creator` — Large / Medium / Small controls Epic count, task volume, and ceremony level
- **Plans-only delivery mode** (Q5) added — creates a single `project.md` under `Plans/<QN_YYYY>/<ProjectName>/` without scaffolding
- **Quarter routing** added to Plans-only mode — Q5 compound answer (e.g. `Plan only, Q3 2026`) places file in the correct quarter subfolder

### Changed
- `project-plan-creator.agent.md` bumped from v1.0 → v1.6
- `.claude/commands/project-plan-creator.md` bumped from v1.1 → v1.6
- Task granularity reduced — consolidated micro-tasks; targets Large 25–35, Medium 15–20, Small 8–12 tasks per plan
- Markdown structure rule added: heading hierarchy (`##` Epics → `###` Features → `####` User Stories → `- **Task**`) — no indentation, prevents code-block rendering in preview

---

## [1.6.0] — 2026-07-06

### Added
- **Appendix section** added as a mandatory numbered section in all HTHB KB articles (between Additional Notes and Troubleshooting)
- Each appendix entry uses `###` numbered sub-headings (`### 1.`, `### 2.`, etc.)
- If no supplementary material exists, agent writes `### 1. Not applicable` — section is never omitted
- Quality Bar check added to enforce Appendix presence

### Changed
- `hthb-generator.agent.md` bumped to v1.6
- `.claude/commands/hthb-generator.md` bumped to v1.6

---

## [1.5.0] — 2026-07-06

### Changed
- **Troubleshooting** moved to be the final section of every KB article — hard rule, no content may appear after it
- Explicit rule statement added to the Troubleshooting section in the output format
- Quality Bar updated with "Troubleshooting is the last section" check
- `hthb-generator.agent.md` bumped to v1.5
- `.claude/commands/hthb-generator.md` bumped to v1.5

---

## [1.4.0] — 2026-07-02

### Added
- PowerShell **first-time setup** and **update** commands added to README
- Copy/no-copy table added to README clearly showing which files must not be copied to project repos
- Recovery note added: `git rm -r --cached` for accidentally staged agent files

---

## [1.3.0] — 2026-07-02

### Added
- **Claude Code** support — full dual-tool structure:
  - `CLAUDE.md` — repo-level background instructions for Claude Code
  - `.claude/commands/project-buddy.md` → `/project-buddy` slash command
  - `.claude/commands/hthb-generator.md` → `/hthb-generator` slash command
  - `.claude/commands/project-plan-creator.md` → `/project-plan-creator` slash command
- README rewritten with Quick Start sections for both GitHub Copilot and Claude Code, doc links, and dual-tool agents table
- `.gitignore` rule in all agent files extended to cover both `.github/agents/` and `.claude/commands/`

---

## [1.2.0] — 2026-07-02

### Added
- **Versioning & Changelog** section added to all three agent files — mandatory four-step checklist before committing
- Section renamed from "Versioning" to "Versioning & Changelog" across all files

### Changed
- Versioning instruction upgraded from a soft suggestion to a mandatory rule with explicit steps

---

## [1.1.0] — 2026-07-02

### Added
- **`.gitignore` rule** added to all three agent files: project repos that copy in `.github/agents/` must gitignore the folder
- **Maintainers callout** added to all three agent files linking back to the central GitLab repo

---

## [1.0.0] — 2026-07-02

### Added
- Initial repository structure
- `.github/agents/` with three GitHub Copilot agent definitions:
  - `project-buddy.agent.md` v1.1 — PowerShell scripting for Tanium, Intune, ITAM, CIS Baseline
  - `hthb-generator.agent.md` v1.4 — HTHB / KB article generator
  - `project-plan-creator.agent.md` v1.0 — Azure DevOps project plan creator
- `README.md` replacing the default GitLab boilerplate

---

> **Maintainers:** When committing changes to this repo, prepend a new entry to this file following the format above.
> Push all changes back to: [BATS / Support Services / AI Agents_Skills · GitLab](https://gitlab.version1.com/bats/support-services/ai-agents_skills)
