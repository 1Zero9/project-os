# Assets

Visual demonstrations and media for the AI Agents & Skills repository.

## GIFs (`/gifs`)

Screen recordings demonstrating agent workflows in action.

### Naming Convention

`{agent-name}_{workflow}_{tool}.gif`

Examples:
- `project-plan-creator_intake-to-approval_claude-code.gif`
- `project-buddy_context-detection_copilot.gif`
- `hthb-generator_repo-mode_claude-code.gif`

### Organization

| Agent | Workflow | Description |
|-------|----------|-------------|
| **Project Plan Creator** | intake-to-approval | User answers 4 questions → plan generated → user approves |
| **Project Buddy** | context-detection | Agent detects project.md → reads context → generates script |
| **Project Buddy** | standalone-task | Agent works without project.md for standalone automation |
| **HTHB Generator** | repo-mode | User points to folder → KB article auto-generated |
| **HTHB Generator** | quick-kb-mode | User describes issue → KB article generated in chat |
| **Endpoint Package Review** | package-creation | User uploads scripts → package generated with detection rules |

### Recording Guidelines

- **Duration**: 5-15 seconds per GIF (keep focused)
- **Resolution**: 1280x720 minimum (readable in GitHub)
- **Speed**: Normal playback speed (no speedup/slowdown)
- **Content**: Show the workflow end-to-end without interruptions
- **Tools**: VS Code (Claude Code ext or Copilot) for consistency
- **Audio**: Silent or subtle background (GIFs are silent anyway)
- **Quality**: Compress before committing (< 5MB per GIF)

### Usage in README

Reference GIFs in markdown:
```markdown
![Agent workflow description](../assets/gifs/agent-name_workflow_tool.gif)
```

## Future Media

- Screenshots for specific UI elements
- Diagrams (architecture, decision flows)
- SVG icons for agents
