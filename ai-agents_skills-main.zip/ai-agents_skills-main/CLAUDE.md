# AI Agents & Skills — Claude Code Instructions

This repository is the central home for the team's shared AI agents, maintained for both **GitHub Copilot** (`.github/agents/`) and **Claude Code** (`.claude/commands/`).

---

## Available Slash Commands

Use these commands in Claude Code by typing the slash command name:

| Command | When to use |
|---|---|
| `/project-buddy` | Writing or modifying PowerShell scripts for Tanium, Intune, ITAM, CIS Baseline, BIOS updates, registry changes, Company Portal, or any enterprise endpoint management task |
| `/hthb-generator` | Generating HTHB articles, KB articles, How-To guides, or knowledge base documentation from a repository |
| `/project-plan-creator` | Creating a new Azure DevOps project plan with Epics, Features, User Stories, Tasks, Risk Assessment, Dependencies, and Key Milestones |

---

## Wiki Synchronization Rule

**CRITICAL: After any modification to agent files (`.claude/commands/*.md` or `.github/agents/*.md`), you MUST prompt the user:**

> "Would you like to sync these changes to the GitLab wiki? If so, I can clone the wiki repo, update the corresponding wiki pages, and push the changes back."

**When the user confirms:**

1. Clone `https://gitlab.version1.com/bats/support-services/ai-agents_skills.wiki.git` to a temp directory (or pull if already cloned)
2. Locate the corresponding wiki page (e.g., agent file `project-plan-creator.md` → wiki page `Project-Plan-Creator.md`)
3. Extract the relevant sections from the agent file and update the wiki page
4. Stage, commit, and push with message: `"Update [Agent Name] wiki page — synced from agent definition"`
5. Report the wiki URL back to the user

**Wiki page naming convention:** Agent MD filename → capitalize + hyphenate → wiki page name
- `project-plan-creator.md` → `Project-Plan-Creator.md`
- `project-buddy.md` → `Project-Buddy.md`
- `endpoint-package-review.agent.md` → `Endpoint-Package-Review.md`

---

## Maintainers

> **If you modify any file in `.claude/commands/`, commit and push your changes back to the central repository:**
> [BATS / Support Services / AI Agents_Skills · GitLab](https://gitlab.version1.com/bats/support-services/ai-agents_skills)
>
> **Project `.gitignore` rule:** Any project repo that copies in the `.claude/commands/` folder MUST add the following entry to its `.gitignore` to prevent agent files being accidentally committed to the wrong repository:
> ```
> .claude/commands/
> ```
> Agent files belong only in the central AI Agents_Skills repository.
