---
name: agent-navigation
description: Use when a user is unsure which AI agent or skill to choose, needs help writing a prompt, or needs an explanation of the agent workflow. Use the repository wiki as the source of truth.
---

# Agent Navigation

Use this shared skill to provide consistent routing advice across the AI Agents & Skills toolkit.

## Authority

The repository wiki is the source of truth for current agent names, responsibilities, workflows, handoffs, and setup guidance.

This skill also supports interactive wiki questions. Retrieve the relevant page before answering current questions about the toolkit.

Read the local wiki copy when available. Prefer:

- `Home/Agents-Skills.md`
- The relevant page under `Home/Agents-Skills/`
- `Home/Setup-Guide/Quickstart-by-Role.md`
- `Home/How-Agents-Work/Skills-and-Hooks/Handoff-Workflows.md`

If the wiki is unavailable, say that current guidance could not be verified. Use local agent definitions only as a fallback and label the result as provisional.

## Wiki question handling

When the user asks how the toolkit works, what an agent or skill does, where guidance lives, or which workflow applies:

1. Search the local wiki first.
2. Retrieve the most relevant page and any directly related page needed for context.
3. Summarize the answer rather than copying large sections.
4. Include the wiki page title and link under `Sources`.
5. Offer a practical next step.

If retrieval fails, label the answer as unverified instead of presenting memory as current.

## Routing questions

Ask only the questions needed to distinguish the route:

1. What outcome does the user want?
2. Do they already have a plan, script, package, or document?
3. What platform or audience is involved?

Do not make the user complete a long intake before recommending a starting point.

## Routing rules

- Project idea, unclear scope, ownership, risks, timeline, or dependencies: **Project Plan Creator**.
- Script, automation, API integration, reporting, or implementation: **Project Buddy**.
- Install, detection, remediation, update, uninstall, or deployment package: **Endpoint Package Review**.
- How-to, knowledge base, SharePoint article, or support documentation: **HTHB Generator**.
- Unclear goal or first-time user: **Help Me: AI Agents & Skills**.

If two agents are plausible, select one primary route and explain the deciding factor. Mention a second option only when it gives the user a real choice.

## Required output

Return:

- The recommended agent
- A plain-language reason
- A refined, ready-to-copy prompt based on the user's request
- A supporting skill when a specialist checklist is relevant
- What the user should expect next
- The next handoff, if applicable
- A reminder to review the result before using or publishing it

## Prompt refinement

Improve rough requests without changing their intent. Preserve user-provided facts, use documented agent responsibilities as context, and ask no more than three focused questions for details that materially affect the work.

The refined prompt should include:

- Goal and desired outcome
- Known context and existing files
- Platform, audience, or scope when known
- Constraints and exclusions
- Expected output
- Validation, testing, or review request

Clearly separate confirmed facts from assumptions. Never invent credentials, names, platforms, deadlines, permissions, technical requirements, or acceptance criteria. Use placeholders such as `[target platform]` when information is unknown.

## Skill routing

Skills support an agent and do not replace it. Recommend the narrowest relevant skill:

- PowerShell validation, unattended execution, exit codes, or ASCII compatibility: `powershell-validation`
- Deployment package review for Intune, SCCM, PatchMyPC, Jamf, or Tanium: `intune-package-review`
- Secret and sensitive-data checks before publishing or committing: `secret-scanning`
- Azure DevOps work items, risks, dependencies, milestones, or CAB decisions: `ado-project-planning`
- Central agent and skill update checks: `agent-update-check`
- New paired agent and command design: `agent-creator`
- Agent selection and prompt refinement: `agent-navigation`

When routing both, name the primary agent first, then explain what the supporting skill checks.

The skill provides routing guidance only. It does not create files, run deployments, approve plans, or send handoffs.
