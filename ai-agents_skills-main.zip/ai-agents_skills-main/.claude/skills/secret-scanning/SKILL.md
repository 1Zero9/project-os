---
name: secret-scanning
description: Use before documenting, committing, publishing, or summarising repository content to detect credentials, tokens, private endpoints, tenant identifiers, and personal data.
---

# Secret Scanning

Scan only the requested scope and inspect matches in context. Check tracked files, staged changes, and relevant diffs for API keys, bearer tokens, passwords, connection strings, private IPs/hostnames, tenant/client/object IDs, emails, and marked secret comments. Redact findings in output, stop publication when a credible secret is found, and recommend rotation/removal. Treat false positives as warnings with evidence, never as proof of safety.
