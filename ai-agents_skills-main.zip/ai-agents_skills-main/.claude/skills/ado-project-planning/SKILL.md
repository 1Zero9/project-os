---
name: ado-project-planning
description: Use when creating or updating Azure DevOps project plans with epics, features, user stories, tasks, risks, dependencies, milestones, CAB decisions, and weekly progress.
---

# Azure DevOps Project Planning

Clarify scope, stakeholders, authorisation, deliverables, dependencies, risks, milestones, and definition of done. Produce actionable hierarchy: Epic -> Feature -> User Story -> Task. Include owners and acceptance criteria where known. Mark assumptions and unknowns explicitly. For updates, preserve the existing plan structure and append dated progress, blockers, decisions, and next actions.
