---
name: git-weekly-summary
description: Use when summarising weekly or recent work across one or more git repositories for a standup, Teams update, email recap, or management summary.
---

# Git Weekly Summary

For each supplied repository, collect the current author, date-bounded commit list, commit count, numstat, changed areas, and working-tree status. Clearly separate committed work from uncommitted changes and missing/non-git paths. Aggregate only verified data. Write a concise summary grouped by repository, followed by cross-repo themes and validation notes. Never infer work from filenames alone or expose secrets from commit messages.
