---
name: agent-creator
description: Use when creating, designing, or reviewing a new GitHub Copilot agent and Claude Code command from a prompt. Inspect existing agents first, reuse shared rules, propose handoffs, and produce paired definitions only after approval.
---

# Agent Creator

Use this skill when a user asks to create a new agent, design an agent from a prompt, turn a workflow into an agent, or decide whether an existing agent should be extended instead.

The skill creates the design and files for both supported tools:

- GitHub Copilot: `.github/agents/<name>.agent.md`
- Claude Code: `.claude/commands/<name>.md`

Keep both definitions aligned in purpose, scope, safety rules, update behavior, and examples. Tool-specific frontmatter and invocation details may differ.

## Required workflow

### 1. Understand the requested agent

Extract:

- The problem the agent solves
- Intended users
- Typical prompts and trigger phrases
- Inputs and outputs
- Required tools and permissions
- Safety or approval requirements
- Whether the agent is standalone, repository-integrated, or both
- Which existing agents should receive work from it or send work to it

Ask focused questions for missing information. Do not invent business rules, permissions, integrations, or vendor behavior.

### 2. Check whether a new agent is justified

Read the existing agent names, descriptions, and relevant wiki pages before designing a new one.

Recommend modifying an existing agent when the request is only:

- A new trigger phrase or example
- A small workflow addition within an existing responsibility
- A new platform that fits an existing agent's domain
- Logic that would otherwise be duplicated

Recommend a new agent when the responsibility is genuinely distinct, needs independent workflows or tools, or will be used independently by multiple teams.

Report the decision and the evidence before writing files.

### 2a. Choose the right customization type

Before recommending an agent, compare the request against the existing repository structure:

| Need | Recommend |
|---|---|
| A distinct role with its own conversation, tools, permissions, or handoffs | **Agent** |
| A reusable checklist or specialist process that multiple agents can invoke | **Shared skill** |
| A deterministic check or action that must run at an agent lifecycle point | **Hook** |
| Always-on guidance for the whole repository or workspace | **Instructions** |
| One focused, parameterized request with no ongoing role | **Prompt** |

Inspect the existing `.github/agents/`, `.github/skills/`, `.github/hooks/`, `.claude/commands/`, `.claude/skills/`, instructions, and relevant wiki pages before deciding. Recommend extending an existing component when the requested behavior fits its current responsibility. Explain why the selected customization type is the smallest suitable change.

### 2a-critical. File structure — AGENTS vs SKILLS

**CRITICAL: Agents and skills use DIFFERENT directory structures. Choose correctly before creating files.**

#### Agents (Distinct roles with their own conversations)

**File structure:**
- GitHub Copilot agent: `.github/agents/<name>.agent.md` (single file, no directory)
- Claude Code command: `.claude/commands/<name>.md` (single file, no directory)

**Example:**
```
.github/agents/project-buddy.agent.md
.claude/commands/project-buddy.md
```

#### Skills (Reusable checklists or processes)

**File structure:**
- GitHub Copilot skill: `.github/skills/<name>/SKILL.md` (directory with SKILL.md inside)
- Claude Code skill: `.claude/skills/<name>/SKILL.md` (directory with SKILL.md inside)

**Example:**
```
.github/skills/update-agents-framework/
  SKILL.md

.claude/skills/update-agents-framework/
  SKILL.md
```

**Golden rule:** If the customization type is **Skill**, both files go in **skills directories** with the filename **SKILL.md**. If the type is **Agent**, both files go in **agents/commands directories** as single files with **.agent.md** or **.md** extension.

### 2b. Scope constraints and token costs

Agent definitions are loaded into every conversation that uses them. Bloated agents cost tokens repeatedly and slow all users down.

Keep agent definitions **under 1,000 lines**. If an agent grows past 1,500 lines, recommend splitting it:

- Extract narrow responsibilities into new agents (e.g., "Package Review" + "Security Review" instead of one agent doing both)
- Move specialist guidance into shared skills (reusable checklists that agents invoke)
- Move examples into wiki pages (linked, not embedded)
- Move detailed workflows into handoffs (next agent takes over with context)

**Token impact:** A 2,000-line agent loaded into every conversation costs 10–15× more than a 200-line focused agent. Splitting reduces per-request cost and makes handoffs faster.

Mention this sizing constraint during the design phase. If the requested agent risks exceeding 1,500 lines, propose splitting it early.

See wiki: [Agent Sizing and Performance](https://gitlab.version1.com/bats/support-services/ai-agents_skills/-/wikis/Home/Creating-and-Updating-Agents-Skills/Agent-Sizing-and-Performance) — decision tree, cost examples, and splitting patterns.

### 3. Apply repository rules

Every generated agent pair must include or follow the repository's current rules:

- The central repository is the source of truth.
- Keep the Copilot and Claude definitions aligned.
- Do not copy the central `README.md`, `CHANGELOG.md`, or `CLAUDE.md` into project repositories.
- Include the project `.gitignore` guidance for copied agent, skill, hook, and command folders.
- Use the `agent-update-check` workflow at startup so users can be offered updates.
- Support non-Git folders; only discuss `.gitignore` when a Git repository is detected.
- Ask before copying updates or making destructive changes.
- Include the wiki synchronization rule for changes to the agent definition.
- Include the markdown commit prompt rule: only ask about committing when the current agent definition itself changes.
- Include the main-repository changelog rule when a user explicitly requests a commit to the central repository.
- Include the lessons-learned rule when the work reveals a reusable pattern or safeguard.
- Never include secrets, tokens, private endpoints, personal data, or invented identifiers.
- Add a version, updated date, maintainer guidance, and a version history section.

Use the current repository files as the source of truth if any rule has changed.

Before writing the definitions, compare the current rules in `CLAUDE.md`, a recent agent definition, and the matching wiki guidance. Do not copy stale rule text from memory.

### 4. Design handoffs from the existing workflow

Inspect the existing Copilot handoffs and agent responsibilities. Suggest only handoffs that are supported by the actual repository.

For each proposed handoff, include:

- Source agent
- Target agent
- When the handoff should appear
- A short context-aware prompt
- `send: false` so the user can review it before sending

Do not create circular or duplicate handoffs. If no handoff is appropriate, state that clearly.

### 5. Draft before writing

Show the user a concise design summary before creating files:

- Proposed name and invocation
- Why a new agent is or is not justified
- Scope and exclusions
- Tools and permissions
- Inputs, outputs, and safety checks
- Proposed handoffs
- Wiki page to create or update

Wait for approval before writing the agent files. If the user asks for a draft only, do not write files.

### 6. Create the paired definitions

After approval:

- Create the GitHub Copilot `.agent.md` file with valid frontmatter.
- Create the Claude Code `.md` command file.
- Keep instructions, examples, safety rules, update behavior, and handoffs aligned.
- Use the repository's current agent template and naming conventions.
- Use a clear description with trigger phrases so the skill and agent can be discovered.

### 7. Document and validate

Update or create the matching wiki page under the existing `Home/Agents-Skills/` hierarchy. Include:

- Overview
- When to use
- When not to use
- Example prompts
- How it works
- Inputs and outputs
- Safety and approval behavior
- Handoffs
- Troubleshooting

After documenting the new or changed agent, skill, or feature, perform a **Help Me impact review**:

- Update `Home/Agents-Skills/Help-Me-AI-Agents-Skills.md` when the change affects agent selection, skill selection, workflow steps, examples, or user-facing terminology.
- Update `Home/Agents-Skills.md` and the wiki sidebar when a new agent or skill needs to appear in navigation.
- Update the Help Me Copilot/Claude definitions only when its routing rules, examples, or response behavior need a change; otherwise rely on its wiki retrieval behavior to discover the new content dynamically.
- Add or update at least one beginner-friendly example prompt when the new capability changes how users should ask for help.

Validate:

- YAML frontmatter parses and includes required fields.
- Both definitions exist and are aligned.
- Handoff targets exist.
- The update-check rule is present.
- Wiki links resolve.
- No secrets or personal data are present.
- `git diff --check` passes.

Report what was created, what was updated, validation performed, and any remaining manual tests.

## Example request

```text
Create an agent that reviews SharePoint migration plans for missing owners, dependencies, risks, and approval gates. It should work in GitHub Copilot and Claude Code, follow the shared update rules, and hand off implementation work to Project Plan Creator.
```

## Expected confirmation prompt

Before writing files, ask for approval in plain language:

> I have a design for the new agent and its Copilot/Claude pair. Would you like me to create the two definitions and update the matching wiki page?

## Important limitation

This skill designs and creates agent definitions; it does not automatically publish them. The user must review and explicitly approve file changes, commits, wiki synchronization, and pushes.
