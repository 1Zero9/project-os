---
name: powershell-validation
description: Use when validating or reviewing PowerShell scripts for syntax, ASCII compatibility, PSScriptAnalyzer issues, exit codes, and unattended execution on Windows endpoints.
---

# PowerShell Validation

1. Identify changed `.ps1` files and read the relevant package context.
2. Check every changed script is ASCII-only when it targets Tanium, Intune, SCCM, or SYSTEM execution.
3. Parse scripts with `System.Management.Automation.Language.Parser` when PowerShell is available.
4. Run `Invoke-ScriptAnalyzer` when PSScriptAnalyzer is installed; report unavailable tooling separately.
5. Verify non-interactive behavior, explicit exit codes, error handling, and detection output.
6. Report failures first, then warnings, then the exact commands run. Never claim validation that was not executed.
