---
name: endpoint-package-review
description: Use when reviewing or creating Intune, SCCM, PatchMyPC, or Tanium application packages, including install, detection, uninstall, remediation, versioning, logging, and SYSTEM-context behavior. Always creates versioned packages and displays install/uninstall commands in chat.
---

# Intune Package Review

Review the package as a deployment contract:
- Confirm install, detection, uninstall, and remediation scripts agree on product and version.
- Check silent switches, SYSTEM compatibility, working directories, 32/64-bit registry views, and exit codes.
- Check retry and reboot behavior, transcript paths, idempotence, and logging.
- Look for auto-updaters, scheduled tasks, services, child processes, and Avecto/CE+ implications.
- Check README coverage and package commands.

Return blocking defects first, then deployment risks, then verified strengths. Do not invent vendor behavior.

## Pre-Packaging Compliance Checks

**Mandatory assessment before packaging any application:**

1. **Is this a paid/commercial application?**
   - If YES: confirm ISS team has approved this app for deployment
   - If approval not confirmed: ask user to contact ISS before proceeding

2. **Has this app been reviewed by Security Team?**
   - If NO: flag as blocking — security review required
   - If YES: note the review status in README

3. **VMRay security scan**
   - Run the app installer through VMRay for malware/behavioral analysis
   - Document any flagged behaviors in README under "Security Review"
   - Link to VMRay report if available

4. **Post to Secure Builds Teams channel**
   - **Before packaging**, notify [**#secure-builds**](https://teams.microsoft.com/l/channel/19%3A10aee2dd1aeb4d6284679080c5f81aa4%40thread.skype/Secure%20Builds?groupId=eea13546-0468-419e-b0db-71b56edd6aa7&tenantId=3e0088dc-0629-4ae6-aa8c-813e7a296f50) in Teams with:
     - App name and installer details
     - Security review status
     - ISS approval status (if paid)
     - Any VMRay findings or flags
   - **Wait for squad member sign-off before proceeding with packaging** (blocking — do not package until team approves)

5. **After packaging is complete**: Add the package to the [Manual Package List](https://version1.sharepoint.com/sites/HTHBKnowledge/Lists/Manual%20Package%20List%20%20Endpoint/AllItems.aspx) in SharePoint with package name, version, filename, and security review summary

## Auto-Package Creation

When writing or updating scripts for Intune, SCCM, PatchMyPC, or Tanium:
1. **Always create the package** after scripts are finalized
2. **Include versioning** on every package — use SemVer format (e.g., `1.0.0`, `1.2.5`) tied to script version or product release
3. **Display package commands in chat** — show both install and uninstall commands in a code block when package is created

Example output format:
```
Install command:
msiexec.exe /i "PackageName_1.0.0.msi" /qn /norestart

Uninstall command:
msiexec.exe /x "PackageName_1.0.0.msi" /qn /norestart
```
