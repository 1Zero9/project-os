---
name: agent-update-check
description: Use at agent startup to check whether the central AI Agents & Skills files are newer than the local agent, skill, hook, or command folders. Ask before updating, support non-Git folders, and check .gitignore only when a Git repository is present.
---

# Agent Update Check

Run this check near the start of every agent session before doing task work.

## Check procedure

1. Identify the current workspace or project folder.
2. Look for these local folders:
   - `.github/agents/`
   - `.github/skills/`
   - `.github/hooks/`
   - `.claude/commands/`
   - `.claude/skills/`
3. Determine which tool is active:
   - Claude Code: update `.claude/commands/` and `.claude/skills/` only.
   - GitHub Copilot: update `.github/agents/`, `.github/skills/`, and `.github/hooks/` only.
   - Both: update both toolsets when the user explicitly wants both in the same workspace.
4. Use the central repository at `https://gitlab.version1.com/bats/support-services/ai-agents_skills.git` as the source of truth.
5. Clone it to `$env:TEMP\ai-agents` if it is not already cloned. On later checks, fetch or pull the latest `main` branch without overwriting local project files.
6. Compare the relevant central folders with the local folders. If the local folders are missing or differ from the central copy, report that updates are available.
7. Do not copy files automatically. Ask the user for confirmation first.

## Confirmation prompt

Use a clear prompt such as:

> Updates are available for the AI agents and skills. Would you like me to update the local agent folders now? I will review the target folders first and only update files after you confirm.

If the local workspace is not a Git repository, use:

> Updates are available for the AI agents and skills. This folder is not a Git repository, so I will only update the agent, skill, command, and hook folders. Would you like me to continue?

## Update procedure after confirmation

1. Confirm the target toolset before updating. Do not copy `.github/agents/` into a Claude-only workspace or `.claude/commands/` into a GitHub-Copilot-only workspace.
2. Check whether the current folder is inside a Git repository with `git rev-parse --show-toplevel`.
3. If it is a Git repository, inspect `.gitignore` before copying. Offer to add missing entries for the folders being copied:
   - `.github/agents/`
   - `.github/skills/`
   - `.github/hooks/`
   - `.claude/commands/`
   - `.claude/skills/`
4. Do not change `.gitignore` without confirmation.
5. If it is not a Git repository, skip `.gitignore` entirely and continue with the folder update after confirmation.
6. Copy only the selected toolset folders from the central repository into the current workspace. Do not copy `README.md`, `CHANGELOG.md`, `CLAUDE.md`, or other central-repository documentation.
7. Report which folders were updated.
8. Explain that Claude Code or VS Code may need a reload before newly copied definitions appear.

The central repository includes `scripts/Update-AIAgents.ps1` for this workflow. Use it with `-ToolSet ClaudeCode`, `-ToolSet GitHubCopilot`, or `-ToolSet Both`.

## Safety rules

- Never overwrite project files silently.
- Never run `git reset`, `git checkout`, or other destructive commands to discard local work.
- If the target agent folders contain uncommitted changes, show the affected paths and ask whether to continue.
- Keep the check lightweight and avoid repeating it multiple times in one session.
- A failed network check should be reported as unavailable; do not treat it as proof that the local files are current.
