---
name: intune-package-review
description: Use when reviewing or creating Intune, SCCM, PatchMyPC, or Tanium application packages, including install, detection, uninstall, remediation, versioning, logging, and SYSTEM-context behavior.
---

# Intune Package Review

Review the package as a deployment contract:
- Confirm install, detection, uninstall, and remediation scripts agree on product and version.
- Check silent switches, SYSTEM compatibility, working directories, 32/64-bit registry views, and exit codes.
- Check retry and reboot behavior, transcript paths, idempotence, and logging.
- Look for auto-updaters, scheduled tasks, services, child processes, and Avecto/CE+ implications.
- Check README coverage and package commands.

Return blocking defects first, then deployment risks, then verified strengths. Do not invent vendor behavior.
