# Update Agent Skills Framework

Use this skill to pull the latest agents and skills from the central repository and update your local environment, whether you're in the central repo itself or a project repository.

The skill:
- Automatically backs up current agents before updating
- Pulls the latest from the central repository
- Copies `.github/agents/` and `.claude/commands/` folders
- Updates `.gitignore` to protect agent files
- Validates agents are readable by Claude and GitHub
- Shows the latest changelog entries

## How This Skill Protects Central Rules

This skill pulls agents and skills from the central AIAgentSkills repository. To prevent Claude from accidentally saving personalized memory that conflicts with central rules:

**The skill updates MEMORY.md with a single rule:** "Do not save memory for agents/skills from AIAgentSkills central repo — they are centrally managed."

This rule prevents Claude from customizing these agents in memory, which would conflict with central control. The rule only applies to AIAgentSkills agents/skills and does not affect other repo-specific rules in MEMORY.md.

## Workflow

### Step 1: Detect environment

Ask: **Are you running this in the central AIAgentSkills repository, or in a project repository that has copied agent files?**

- **Central repo**: Update agents in place
- **Project repo**: Copy latest from central repo, update `.github/agents/` and `.claude/commands/` folders

### Step 2: Back up current agents

Before pulling updates, back up the current agent/skill folders to:
```
$env:APPDATA\AIAgentSkills\YYYY-MM-DD_HHmmss\
```

Include both:
- `.github/agents/` and `.github/skills/` (if exist)
- `.claude/commands/` and `.claude/skills/` (if exist)

Keep only 1 backup — delete the previous backup before creating a new one.

If backup fails, warn user and ask before proceeding.

### Step 3: Clone or pull latest

**Central repo:**
```powershell
git pull origin main
```

**Project repo:**
- If central repo already exists at `$env:APPDATA\AIAgentSkills\repo`, pull latest:
  ```powershell
  cd "$env:APPDATA\AIAgentSkills\repo"
  git pull origin main
  ```
- If not cloned, clone it:
  ```powershell
  git clone https://gitlab.version1.com/bats/support-services/ai-agents_skills.git "$env:APPDATA\AIAgentSkills\repo"
  ```

If git is not available or no connectivity, handle gracefully:
- Warn: "Git not found or no internet connectivity"
- Offer manual fallback: "Download the repo as ZIP and extract to the AppData folder"
- Stop gracefully (do not error)

### Step 4: Copy folders

**From central repo to project repo:**

Copy these folders from the central repo to your current directory:
- `$env:APPDATA\AIAgentSkills\repo\.github\agents\` → `.\.github\agents\`
- `$env:APPDATA\AIAgentSkills\repo\.github\skills\` → `.\.github\skills\`
- `$env:APPDATA\AIAgentSkills\repo\.claude\commands\` → `.\.claude\commands\`
- `$env:APPDATA\AIAgentSkills\repo\.claude\skills\` → `.\.claude\skills\`

Overwrite existing files.

### Step 5: Update .gitignore

If `.gitignore` exists in the project repo, add these lines if missing:

```
.claude/commands/
.claude/skills/
.github/agents/
.github/skills/
```

These entries ensure agent and skill files don't get committed to the project repo by accident.

If no `.gitignore`, skip (user may not have one).

### Step 6: Validate agents and skills

For each `.md` file in `.github/agents/`, `.github/skills/`, `.claude/commands/`, and `.claude/skills/`:

1. **Check YAML frontmatter:**
   - Must have `---` delimiters
   - Must include `name:` and `description:`
   - Must be valid YAML (no parse errors)

2. **Check readability:**
   - File must not be empty
   - Must have content after frontmatter
   - Look for required sections (e.g., workflow, instructions, examples)

3. **Report:**
   - `✓ 15 agents validated`
   - If any fail: `⚠ 2 agents failed validation: [list filenames]`
   - If all pass: Continue to changelog

If validation fails, ask user: "Fix errors before updating?" or proceed anyway?

### Step 7: Show changelog

Extract and display the **last 5–10 entries** from the central repo's `CHANGELOG.md`:

```powershell
head -n 100 "$env:APPDATA\AIAgentSkills\repo\CHANGELOG.md"
```

Format as:
```
📋 Latest updates:

[Unreleased] — 2026-09-11
- Endpoint Package Review — added critical safety rule...
- README.md — clarified that the repository is made of...
- (more entries...)
```

### Step 8: Update MEMORY.md (if in project repo)

If MEMORY.md exists in the project repo, add or update this entry:

```
- [AIAgentSkills Central Repo](do-not-customize) — Do not save memory for agents/skills from AIAgentSkills central repo; they are centrally managed
```

If other repo-specific rules exist in MEMORY.md, leave them untouched. Only add/update the AIAgentSkills entry.

If MEMORY.md doesn't exist, skip (not all projects use memory).

### Step 9: Complete

Report:
```
✅ Update complete!

Backup: $env:APPDATA\AIAgentSkills\YYYY-MM-DD_HHmmss\
Agents: 15 files copied
Skills: 8 files copied
MEMORY.md: Updated (AIAgentSkills rule added)
Validation: ✓ All passed
```

## Error handling

| Scenario | Action |
|---|---|
| No git / no internet | Warn gracefully, suggest manual ZIP download, stop |
| Backup fails | Warn, ask to proceed or stop |
| Agent validation fails | Warn, ask to fix or proceed |
| .gitignore missing | Skip (ok for non-git folders) |
| Backup already exists | Delete old backup, create new one |

## Safety notes

- Do NOT commit agents/skills back to the project repo (they stay in `.gitignore`)
- Do NOT modify agent/skill content — only copy from central repo
- Always back up before overwriting
- Validate before reporting success
- Only add/update the AIAgentSkills rule in MEMORY.md; do not touch other repo-specific rules
