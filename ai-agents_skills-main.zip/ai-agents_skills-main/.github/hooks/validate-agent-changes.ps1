$inputObject = [Console]::In.ReadToEnd() | ConvertFrom-Json
$changedFiles = @(git diff --name-only --diff-filter=ACMR; git diff --cached --name-only --diff-filter=ACMR) | Sort-Object -Unique
$scriptFiles = $changedFiles | Where-Object { $_ -match '\.ps1$' -and (Test-Path $_) }

foreach ($file in $scriptFiles) {
    $bytes = [IO.File]::ReadAllBytes((Resolve-Path $file))
    if ($bytes | Where-Object { $_ -gt 0x7F }) {
        Write-Error "Non-ASCII punctuation detected in $file"
        exit 2
    }

    $tokens = $errors = $null
    [System.Management.Automation.Language.Parser]::ParseFile((Resolve-Path $file), [ref]$tokens, [ref]$errors) | Out-Null
    if ($errors.Count -gt 0) {
        $errors | ForEach-Object { Write-Error "$file`: $($_.Message)" }
        exit 2
    }

    if (Get-Command Invoke-ScriptAnalyzer -ErrorAction SilentlyContinue) {
        $analysis = Invoke-ScriptAnalyzer -Path $file -Severity Error
        if ($analysis) {
            $analysis | ForEach-Object { Write-Error "$file`: $($_.RuleName) - $($_.Message)" }
            exit 2
        }
    }
}

$diff = git diff --cached; $diff += git diff
$secretPattern = '(?i)(password\s*=| bearer\s+[A-Za-z0-9._-]{20,}|api[_-]?key\s*=|-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----|connectionstring\s*=)'
if ($diff -match $secretPattern) {
    Write-Error 'Potential secret detected in the current git diff. Review and redact before continuing.'
    exit 2
}

$diffCheck = git diff --check 2>&1
if ($LASTEXITCODE -ne 0) {
    $diffCheck | ForEach-Object { Write-Error $_ }
    exit 2
}
