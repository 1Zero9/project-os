# AI Agents & Skills

![AI Agents & Skills](assets/images/AIFramworklogo.png)

A shared repository for the team's GitHub Copilot and Claude Code agents. The repo is made up of structured Markdown files: agent files define the role, skills provide reusable checklists, hooks add supporting checks, and wiki pages explain how to use everything. Copy or reference the relevant folders in your VS Code workspace so Copilot and Claude Code can load the same approved guidance.

> 📚 **[Please see the Wiki to get started](https://gitlab.version1.com/bats/support-services/ai-agents_skills/-/wikis/Home)** — setup guides, workflows, and troubleshooting for all agents.

> 🎥 **[Watch the Framework Demo](https://version1.sharepoint.com/:v:/r/sites/HTHBKnowledge/Shared%20Documents/Video/AI_AgentsSkills_Framework_Demo_Sep26.mp4?d=w80ee34f23d3f4f939796f8994ce57683&csf=1&web=1&e=zkHDzF)** — See the AI Agents & Skills framework in action.

## Available Agents

These agents cover the main project workflow from planning through deployment and documentation. Choose an agent below, then use the GitHub Copilot link or Claude Code command to get started.

| Agent | Best for | GitHub Copilot | Claude Code |
|---|---|---|---|
| **Help Me: AI Agents & Skills** | Finding the right agent or skill, writing a prompt, and understanding what happens next | [Open agent](.github/agents/help-me-ai-agents-skills.agent.md) | `/help-me-ai-agents-skills` |
| **Project Plan Creator** | Turning an idea into a project plan with scope, timeline, team, risks, and milestones | [Open agent](.github/agents/project-plan-creator.agent.md) | `/project-plan-creator` |
| **Project Buddy** | Writing scripts and automation for PowerShell, Python, Bash, infrastructure, and reporting | [Open agent](.github/agents/project-buddy.agent.md) | `/project-buddy` |
| **Endpoint Package Review** | Preparing install, detection, remediation, and uninstall packages for Intune, SCCM, Jamf, PatchMyPC, and Tanium | [Open agent](.github/agents/endpoint-package-review.agent.md) | `/endpoint-package-review` |
| **HTHB Generator** | Creating SharePoint-ready how-to and knowledge base articles from a repository or a description | [Open agent](.github/agents/hthb-generator.agent.md) | `/hthb-generator` |

**Not sure where to start?** Use **Help Me: AI Agents & Skills**. It will recommend the right starting point and prepare a prompt for you.

**Typical workflow:** Help -> Plan -> Script -> Package -> Document

### How the agents work together

![Agents working together](assets/images/AgentsWorkingTogether.jpg)

Think of the agents as a simple team:

1. **Project Plan Creator** turns an idea into a clear plan.
2. **Project Buddy** turns the plan into scripts or automation.
3. **Endpoint Package Review** prepares the scripts for safe deployment.
4. **HTHB Generator** explains the finished work in a clear how-to or knowledge article.

Each agent focuses on one stage and can pass useful context to the next stage. You can use them individually, or move through the full workflow from **plan -> build -> package -> explain**.

---

## What Are Agents?

Agents are AI teammates that help you work faster. Each one focuses on one job. See the wiki's [Agents and Skills overview](https://gitlab.version1.com/bats/support-services/ai-agents_skills/-/wikis/Home/Agents-Skills) for a simple explanation of each agent and when to use it.

The agents work together as a workflow: **Plan → Script → Package → Document**.

### Why Agents Matter

**Speed**
- Plan in 30 minutes instead of days of meetings
- Write production-ready scripts in 4 hours instead of 1-2 weeks
- Package for deployment in 1 hour instead of manual config

**Consistency**
- Same workflow, same quality across the team
- Every project follows Plan → Script → Package → Document
- Knowledge stays in the team, not with one person

**Safety**
- Scripts validated for syntax, ASCII, and analysis errors
- Secrets scanning before anything ships
- Peer review built in — audit trails on what changed
- **⚠️ Always review AI-generated code before production.** Have a team member test and verify. AI is powerful but not infallible.

**Lower Barrier to Entry**
- Support engineers and managers can use Plan Creator
- No deep coding needed to start
- Agents handle syntax, formatting, validation

---

## Skills vs Agents

![Skills vs Agents](assets/images/AgentsVsSkills.png)

**Agents** are full workflows that guide you through complex projects step by step. **Skills** are focused specialist checks — reusable validation tools that work inside agents and with your own code. Both work in Claude Code and GitHub Copilot.

See the wiki for detailed guides: [Shared Skills](https://gitlab.version1.com/bats/support-services/ai-agents_skills/-/wikis/Home/How-Agents-Work/Skills-and-Hooks/Shared-Skills) — list, examples, and when to use each one.

### Shared Skills

Shared skills are specialist checklists that help the AI handle particular jobs consistently. For example, a PowerShell skill can check a script for common problems before you use it.

The same skills work with GitHub Copilot and Claude Code.

| Skill | Purpose |
|-------|---------|
| PowerShell checker | Checks scripts for errors, unsafe characters, correct exit codes, and problems that could stop them working automatically |
| Deployment package checker | Checks that software can be installed, found, updated, removed, and logged correctly on a computer |
| Git work summary | Creates a reliable summary of recent work across one or more repositories |
| Secret checker | Looks for passwords, access keys, private addresses, personal details, and other information that should not be published |
| Azure DevOps planner | Helps break a project into work items, risks, dependencies, approvals, and milestones |
| Agent update checker | Checks for newer agent, skill, hook, and command files and asks before updating them |
| Agent creator | Designs paired Copilot and Claude agents, applies repository rules, and suggests safe handoffs |

## Specialist Reviewers and Hooks

Specialist reviewers are focused checks that agents can use for scripts, packages, summaries, security, and project planning. Hooks are automatic checks that run after agent actions or when a session ends.

For the diagram, detailed explanations, and examples, see [Specialist Reviewers and Hooks](https://gitlab.version1.com/bats/support-services/ai-agents_skills/-/wikis/Home/How-Agents-Work/Skills-and-Hooks).

---

## Handoff Workflows (GitHub Copilot)

In GitHub Copilot, a handoff button can pass your work to the next agent with useful context already prepared. You can review the suggested request before sending it.

See the wiki for the image, workflow table, and full explanation: [Handoff Workflows](https://gitlab.version1.com/bats/support-services/ai-agents_skills/-/wikis/Home/How-Agents-Work/Skills-and-Hooks/Handoff-Workflows).

---

## Token Optimization & Cost Management

AI agents are efficient, but token usage adds up. Learn how to minimize costs and keep requests fast by using the right model, batching similar work, and structuring prompts clearly. These techniques work the same way in both Claude Code and GitHub Copilot.

**See:** [Token Optimization Guide](https://gitlab.version1.com/bats/support-services/ai-agents_skills/-/wikis/Home/Agents-Skills/Token-Optimization-Guide)

Key strategies:
- Use Haiku for simple tasks (90% cost reduction)
- Batch similar requests (50-60% savings)
- Provide context once, reuse it (40-60% savings)
- Write specific prompts (30-50% savings)
- Pick the specialized agent for your task (fewer clarifications, faster results)

---

## How It Works

Both Claude Code and GitHub Copilot support these agents with identical workflow and output. See [How Agents Work](https://gitlab.version1.com/bats/support-services/ai-agents_skills/-/wikis/Home/How-Agents-Work) — setup guides, examples, and tool-specific workflows.

---

## 🚀 Getting Started — See the Wiki!

**👉 All setup, workflows, and troubleshooting are in the [Wiki](../../wiki).**

---

## Future Plans and Work in Progress

This section is separate from the currently available agents. It records ideas and possible future work that still need access, licensing, security, governance, or design decisions.

### Microsoft Copilot Integration (WIP)

Microsoft 365 Copilot / Copilot Studio may be able to support translated versions of these agents and skills. Nothing here is implemented or production-ready.

- [Microsoft Copilot WIP notes](microsoft-copilot/README.md) — feasibility, prerequisites, and a possible implementation approach
- [Future Ideas and Plans wiki page](https://gitlab.version1.com/bats/support-services/ai-agents_skills/-/wikis/Home/How-Agents-Work/Future-Ideas-and-Plans) — shared backlog for ideas, plans, blockers, pilots, and decisions

### New Skills

#### Tanium Script Reference (Idea)

Create a shared **Tanium Script Reference** skill that can read a central Tanium scripts repository for troubleshooting and package review. It should search remote repository content where possible and avoid cloning by default. Use it with Endpoint Package Review to compare endpoint logs, Tanium action history, package command lines, and known script behavior.

### Agent Enhancements

#### Tanium Atlas integration (Idea)

Tanium Atlas could optionally provide read-only endpoint evidence for package reviews and troubleshooting, including device inventory, application state, Jamf/Tanium context, and privilege-management evidence. This is a future idea only; access, API details, permissions, security review, and safe query boundaries still need to be confirmed.

- [Future Ideas and Plans wiki page](https://gitlab.version1.com/bats/support-services/ai-agents_skills/-/wikis/Home/How-Agents-Work/Future-Ideas-and-Plans) — Atlas planning entry and next questions

#### Company Portal Installer Publishing (Idea)

Extend Endpoint Package Review to automatically create and publish installers and packages to Company Portal for internal team distribution. This would streamline the workflow for packaging applications that are deployed internally, reducing manual steps for uploading, testing, and managing versions.

### Agent Token Usage Refinement (Planned)

Ongoing work to optimize token usage across all agents and reduce per-conversation cost. Includes periodic review of agent size, splitting large agents, moving guidance to shared skills, and linking examples to wiki pages instead of embedding them.

- All agents should stay under 1,000 lines; agents over 1,500 lines should be considered for splitting.
- Shared skills are loaded once per conversation and reused; they save tokens compared to embedded guidance.
- Wiki links are free if users don't click them; example libraries should be wiki-linked, not embedded.
- Cost tracking: measure token usage before/after optimization and include in pull request descriptions.

See: [Agent Sizing and Performance](https://gitlab.version1.com/bats/support-services/ai-agents_skills/-/wikis/Home/Creating-and-Updating-Agents-Skills/Agent-Sizing-and-Performance) — decision tree, splitting patterns, and cost examples. Updated agent-creator skill section 2b with sizing constraints.

### Planning rule

Future ideas should be marked clearly as **Idea**, **Planned**, **Blocked**, **Pilot**, **Complete**, or **Dropped**. They are not commitments until the required approvals and access are confirmed.

---

## Contributing

This repository is the central source of truth for the shared agents and skills. Keep changes synchronized here and do not let local updates go unshared.

For instructions on creating or updating agents and skills, including paired Copilot/Claude definitions, wiki synchronization, version history, validation, and review, see:

- [Creating and Updating Agents/Skills](https://gitlab.version1.com/bats/support-services/ai-agents_skills/-/wikis/Home/Creating-and-Updating-Agents-Skills)
- [Step-by-Step: Create Your First Agent](https://gitlab.version1.com/bats/support-services/ai-agents_skills/-/wikis/Home/Creating-and-Updating-Agents-Skills/Creating-New-Agents#step-by-step-create-your-first-agent)
- [Adding Changes to Agents](https://gitlab.version1.com/bats/support-services/ai-agents_skills/-/wikis/Home/Creating-and-Updating-Agents-Skills/Adding-Changes-to-Agents)

Main repository: [BATS / Support Services / AI Agents_Skills](https://gitlab.version1.com/bats/support-services/ai-agents_skills)
